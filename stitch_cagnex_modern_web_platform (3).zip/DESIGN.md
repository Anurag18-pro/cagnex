---
name: Autonomous Underwriting & Intelligence Workstation
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353943'
  surface-container-lowest: '#0a0e17'
  surface-container-low: '#181b25'
  surface-container: '#1c1f29'
  surface-container-high: '#262a34'
  surface-container-highest: '#31353f'
  on-surface: '#dfe2ef'
  on-surface-variant: '#c3c6d7'
  inverse-surface: '#dfe2ef'
  inverse-on-surface: '#2c303a'
  outline: '#8d90a0'
  outline-variant: '#434655'
  surface-tint: '#b4c5ff'
  primary: '#b4c5ff'
  on-primary: '#002a78'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#0053db'
  secondary: '#bfc6df'
  on-secondary: '#283043'
  secondary-container: '#3f465b'
  on-secondary-container: '#adb5cd'
  tertiary: '#adc6ff'
  on-tertiary: '#002e6a'
  tertiary-container: '#0f69dc'
  on-tertiary-container: '#edf0ff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dbe2fb'
  secondary-fixed-dim: '#bfc6df'
  on-secondary-fixed: '#131b2d'
  on-secondary-fixed-variant: '#3f465b'
  tertiary-fixed: '#d8e2ff'
  tertiary-fixed-dim: '#adc6ff'
  on-tertiary-fixed: '#001a42'
  on-tertiary-fixed-variant: '#004395'
  background: '#0f131c'
  on-background: '#dfe2ef'
  surface-variant: '#31353f'
  canvas-base: '#090D16'
  surface-panel: '#0D1527'
  surface-elevated: '#131C35'
  border-hairline: rgba(255, 255, 255, 0.08)
  border-active: rgba(37, 99, 235, 0.5)
  status-success: '#10B981'
  status-warning: '#F59E0B'
  status-critical: '#EF4444'
  source-highlight-fill: rgba(37, 99, 235, 0.18)
  text-primary: '#F8FAFC'
  text-muted: '#94A3B8'
  text-faint: '#475569'
typography:
  display-kpi:
    fontFamily: JetBrains Mono
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Geist
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.01em
  body-base:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: -0.006em
  body-semibold:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.006em
  body-compact:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  legal-clause:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: -0.01em
  data-mono-bold:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: -0.01em
  table-header:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.06em
  badge-label:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
  meta-stamp:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.375rem
  space-md: 0.5rem
  space-lg: 0.75rem
  space-xl: 1rem
---

## Brand & Style

### Personality & Core Pillars
The brand personality is institutional, surgical, defensible, and razor-sharp. Built for principal investors, managing directors, and private credit underwriters, it replaces ornamental noise with uncompromising precision. The UI conveys the authoritative weight of an institutional credit committee memorandum while delivering the sub-50ms reactive ergonomics of high-frequency engineering workspaces (Linear, Palantir Foundry, Bloomberg Terminal).

### Visual Movement & Aesthetic Direction
- **High-Density Technical Minimalist:** Decorative whitespace is minimized; spacing communicates rigorous hierarchy and analytical density.
- **Glassmorphic Hairlines & Dark Obsidian Canvas:** Deep obsidian and midnight navy substrates layered with `rgba(255, 255, 255, 0.08)` hairline borders, subtle directional light bleeds, and focused technical luminance.
- **Deterministic Color Signifiers:** Color never acts as cosmetic wallpaper. Chromatic bandwidth is reserved strictly for interactive vectors, deterministic mathematical verification, and covenant risk gradients.
- **Defensible Auditability:** Every financial metric and covenant ratio acts as an active vector tethered bidirectionally to underlying credit agreement PDF coordinates.

## Colors

### Color Strategy & Architecture
The palette is calibrated for 12+ hour analytical deep-work sessions in institutional credit environments. Dark mode is default, constructed across layered obsidian foundations.

- **Canvas & Structural Surfaces:**
  - `canvas-base` (`#090D16`): The ultimate viewport root.
  - `surface-panel` (`#0D1527`): Primary operational shell, panels, and split-screen structural viewports.
  - `surface-elevated` (`#131C35`): Interactive cards, popovers, table headers, and modal dialogues.
- **Cobalt Accents & Interactive Systems:**
  - Primary Cobalt (`#2563EB`) drives high-intent triggers, source-highlight outlines, and selected row indicators.
  - Secondary Cobalt (`#3B82F6`) provides micro-glow badges, active tabs, and focus vectors.
  - `source-highlight-fill` (`rgba(37, 99, 235, 0.18)`) is reserved for SVG PDF citation bounding boxes.
- **Deterministic Semantic Triad:**
  - `status-success` (`#10B981`): Reconciled adjustments, passing tests, mathematical parity.
  - `status-warning` (`#F59E0B`): Ambiguous legal definitions, covenant erosion, watchlist parameters.
  - `status-critical` (`#EF4444`): Covenant breaches, cross-default provisions, unverified variance spikes.

## Typography

### Structural Pairings & Roles
- **Display & Sectioning (`Geist`):** Delivers clean, geometric tension for operational action bars, pipeline page titles, modal heads, and executive memo summaries.
- **Narrative & Document Body (`Inter`):** Handles dense multi-paragraph credit agreements, compliance notes, and legal clauses.
- **Financial Monospace (`JetBrains Mono`):** Standardizes every financial figure, covenant ratio, GAAP tag, delta metric, and metadata stamp. Employs tabular lining figures (`tnum`) across all instances to preserve vertical decimal alignment across comparative tables.

### Rules of Engagement
- Table headers and metadata chains are rendered in uppercase with deliberate tracking (`0.06em` to `0.08em`).
- Negative variances (`−5.5%`) and positive expansions (`+0.8%`) must always use true minus signs (`U+2212`) and monospace numerals.

## Layout & Spacing

### Layout Philosophy
This design system uses a fixed-fluid hybrid layout engineered for full-viewport analytical density (`100vw` / `100vh`). It eliminates loose decorative margins in favor of high-performance operational viewports:

- **Top Action Bar:** Fixed 48px height across the top coordinate plane. Houses global search, multi-tenant workspace switchers, real-time sync indicators, and analyst presence avatars.
- **Global Navigation Rail:** Dual-state left navigation:
  - Collapsed icon-only rail: 64px width.
  - Expanded institutional rail: 240px width.
- **Dual-Pane Split Workbench:**
  - Pane 1 (Evidence Canvas / PDF Rendering): 50% default width, resizable down to 35%.
  - Pane 2 (Structured Intelligence / Financial Modeling): 50% default width, resizable up to 65%.
  - Separated by an interactive 4px draggable splitter border.

### Spacing Scale & Rhythms
The micro-spacing framework functions on a compact 4px baseline rhythm (`space-xs` = 4px, `space-sm` = 6px, `space-md` = 8px, `space-lg` = 12px, `space-xl` = 16px).
Data grids enforce 32px cell heights for compact mode and 40px cell heights for expanded mode.

## Elevation & Depth

### Depth Philosophy: Hairline Structures over Skeuomorphism
Depth is defined by luminous tonal layering and precise stroke boundaries rather than diffuse drop shadows:

1. **Substrate Level (Z0):** `canvas-base` (`#090D16`), completely flat, hosting structural split-panes.
2. **Panel Tier (Z1):** `surface-panel` (`#0D1527`), defined by a solid `1px` border of `rgba(255, 255, 255, 0.08)`.
3. **Elevated Elements (Z2):** Covenant cards, financial reconciliation cells, and active tabs (`#131C35`) with an ambient inner stroke (`box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.06)`).
4. **Interactive Bounding Boxes:** PDF citation overlays use an SVG coordinate path: `border: 1.5px solid #2563EB; background: rgba(37, 99, 235, 0.18); box-shadow: 0 0 12px rgba(37, 99, 235, 0.35)`.
5. **Overlays & Drawers (Z3):** Overlay dialogues (`NEW DEAL ROOM`, Audit Log Drawer) utilize `box-shadow: 0 16px 40px -8px rgba(0, 0, 0, 0.8), 0 0 0 1px rgba(255, 255, 255, 0.12)`.

## Shapes

### Shape Language & Radius Hierarchy
The interface enforces a compact, institutional corner radius (`roundedness: 1`):
- **Base Components (Inputs, Buttons, Badges, Table Rows):** Fixed `6px` radius (`0.375rem`).
- **Surface Panels & Modals:** Fixed `8px` radius (`0.5rem`).
- **Interactive Bounding Box Highlights:** Precision `2px` radius on document vectors to align with vector-traced typographic bounding boxes.
- **Pills / Status Dots:** Circular `9999px` radius restricted exclusively to real-time status pulses (`●`) and user presence indicators.

## Components

### 1. Interactive Action Buttons
- **Primary Button (`New Deal Room`, `Run Compliance Check`):**
  - Height: 32px.
  - Background: `#2563EB`, Hover: `#1D4ED8`, Border: `1px solid rgba(255, 255, 255, 0.15)`.
  - Typography: `Inter`, 13px, weight 600.
  - Padding: `0 12px`. Radius: 6px.
  - Shadow: Micro cobalt glow `0 0 10px rgba(37, 99, 235, 0.25)`.
- **Ghost Utility Button (`Override Value`, `Export CSV`):**
  - Height: 32px.
  - Background: `rgba(255, 255, 255, 0.03)`, Hover: `rgba(255, 255, 255, 0.07)`.
  - Border: `1px solid rgba(255, 255, 255, 0.08)`. Text: `#F8FAFC`.

### 2. Micro-Glow Status Badges & Chips
- Structure: 20px fixed height, inline-flex, items-center, gap: 5px, padding: `2px 8px`, radius: 4px.
- **Critical Breach:** Background `rgba(239, 68, 68, 0.12)`, Border `1px solid rgba(239, 68, 68, 0.35)`, Text `#EF4444`. Monospace 11px.
- **Caution / Watchlist:** Background `rgba(245, 158, 11, 0.12)`, Border `1px solid rgba(245, 158, 11, 0.35)`, Text `#F59E0B`. Monospace 11px.
- **Verified Parity:** Background `rgba(16, 185, 129, 0.12)`, Border `1px solid rgba(16, 185, 129, 0.35)`, Text `#10B981`. Monospace 11px.
- **Parsing Active:** Cobalt tint with a 6px pulsing dot animation (`@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }`).

### 3. Financial Reconciliation Data Grid
- Header Row: 28px height, uppercase `table-header` in `JetBrains Mono`, text color `#94A3B8`, background `#0D1527`. Border-bottom: `1px solid rgba(255, 255, 255, 0.08)`.
- Data Cells: 32px height, padding: `0 10px`. Values set in `JetBrains Mono` 13px tabular figures.
- Hover & Trace Link: Row hover transitions background to `rgba(37, 99, 235, 0.06)` within 50ms. Clicking any variance initiates bidirectional PDF pane scroll-sync.

### 4. Form Inputs & Facility Pickers
- **Text Inputs (`Facility Size`, `Borrower Name`):**
  - Height: 34px. Background: `#090D16`. Border: `1px solid rgba(255, 255, 255, 0.12)`.
  - Focus state: Border: `1.5px solid #2563EB`, Shadow: `0 0 0 1px #2563EB`.
  - Typography: `Inter` 13px, placeholder in `#475569`.
- **Facility Selector Segmented Chips:**
  - Grouped container background: `#090D16`, border: `1px solid rgba(255, 255, 255, 0.08)`.
  - Selected Segment: Background `#1E293B`, Text `#F8FAFC`, Border `1px solid rgba(255, 255, 255, 0.16)`.

### 5. Multi-Scenario Covenant Cards
- Container: Surface `#0D1527`, radius 8px, border `1px solid rgba(255, 255, 255, 0.08)`, padding: 12px.
- Metrics Grid: 3-column sensitivity matrix (`Base`, `Downside`, `Severe`) displayed with inline headroom delta metrics (`+0.35x headroom` in emerald or `-0.20x breach` in crimson).
- Source Traceability Footnote: Monospace 10px anchor line (`⌁ Source linked · §7.02(b) · confidence 99.8%`) interactive on hover.